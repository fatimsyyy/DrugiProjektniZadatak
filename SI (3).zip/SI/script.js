const checkbox = document.getElementById('dark-mode');
const body = document.body;

checkbox.addEventListener('change', function() {
    if (checkbox.checked) {
        body.style.backgroundImage = 'url("sarajevon.jpg")'; 
    } else {
        body.style.backgroundImage = 'url("sarajevo.jpg")'; 
    }
});



